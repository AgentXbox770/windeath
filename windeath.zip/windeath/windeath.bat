@echo off
title ""

:: Launch video player (fullscreen, topmost, black background)
start "" powershell -NoProfile -WindowStyle Hidden -Command ^
    Add-Type -AssemblyName PresentationFramework; ^
    Add-Type -AssemblyName PresentationCore; ^
    Add-Type -AssemblyName System.Windows.Forms; ^
    $playerWindow = New-Object System.Windows.Window; ^
    $playerWindow.Title = 'THEY ARE COMING TO YOU'; ^
    $playerWindow.WindowStyle = 'None'; ^
    $playerWindow.ResizeMode = 'NoResize'; ^
    $playerWindow.WindowState = 'Maximized'; ^
    $playerWindow.Topmost = $true; ^
    $playerWindow.Background = 'Black'; ^
    $mediaElement = New-Object System.Windows.Controls.MediaElement; ^
    $mediaElement.Background = 'Black'; ^
    $mediaElement.Source = (New-Object System.Uri('%cd%\video1.mp4')); ^
    $mediaElement.LoadedBehavior = 'Play'; ^
    $mediaElement.Stretch = 'UniformToFill'; ^
    $mediaElement.Volume = 1.0; ^
    $playerWindow.Content = $mediaElement; ^
    $playerWindow.ShowDialog()

:: Wait a moment for video to start
timeout /t 2 /nobreak >nul

:: Popup 1
start "" powershell -noprofile -windowstyle hidden -command ^
"$ws = New-Object -ComObject WScript.Shell; ^
$ws.Popup('No system power options has been found during the process of ntoskrnl.exe', 0, 'System power options failed', 16)"

:: Popup 2
start "" powershell -noprofile -windowstyle hidden -command ^
"$ws = New-Object -ComObject WScript.Shell; ^
$ws.Popup('', 0, 'taskman.exe', 48)"

:: Popup 3
start "" powershell -noprofile -windowstyle hidden -command ^
"$ws = New-Object -ComObject WScript.Shell; ^
$ws.Popup('Hard drive or running processors cannot be found while running syssys', 0, 'explorer.EXE', 16)"

pause